hello there
you've reached the readme of our blockchain project
to run this project, you'll need to  run the following command : 

truffle migrate

the command will allow multiple passengers to get their ridepass
